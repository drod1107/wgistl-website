/** @type {import('next').NextConfig} */
const nextConfig = {
  webpack: (config, { isServer }) => {
    // Prevent source map loading issues
    if (!isServer) {
      config.devtool = 'source-map'
    }
    return config
  },
    images: {
      remotePatterns: [
        {
          protocol: 'https',
          hostname: 'i.ytimg.com',
          port: '',
          pathname: '/vi/**',
        }
      ]
    }
  }
export default nextConfig;
