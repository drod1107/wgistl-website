// Tailwind CSS Configuration (tailwind.config.js)
// Tailwind configuration file for customizing styles
module.exports = {
    darkMode: ['class'],
	content: [
		'./app/**/*.{js,ts,jsx,tsx}', // Scans everything in the 'app' folder
		'./components/**/*.{js,ts,jsx,tsx}', // Scans components folder
		'./src/**/*.{js,ts,jsx,tsx}', // Make sure to scan everything in the 'src' folder if you have components there
		'./node_modules/@shadcn/ui/**/*.js' // Include ShadCN components
	  ],
  theme: {
  	extend: {
  		colors: {
  			hero: '#C41E3A',
  			blue: '#002F87',
  			gold: '#FDB927',
  			background: 'hsl(var(--background))',
  			foreground: 'hsl(var(--foreground))',
  			card: {
  				DEFAULT: 'hsl(var(--card))',
  				foreground: 'hsl(var(--card-foreground))'
  			},
  			popover: {
  				DEFAULT: 'hsl(var(--popover))',
  				foreground: 'hsl(var(--popover-foreground))'
  			},
  			primary: {
  				DEFAULT: 'hsl(var(--primary))',
  				foreground: 'hsl(var(--primary-foreground))'
  			},
  			secondary: {
  				DEFAULT: 'hsl(var(--secondary))',
  				foreground: 'hsl(var(--secondary-foreground))'
  			},
  			muted: {
  				DEFAULT: 'hsl(var(--muted))',
  				foreground: 'hsl(var(--muted-foreground))'
  			},
  			accent: {
  				DEFAULT: 'hsl(var(--accent))',
  				foreground: 'hsl(var(--accent-foreground))'
  			},
  			destructive: {
  				DEFAULT: 'hsl(var(--destructive))',
  				foreground: 'hsl(var(--destructive-foreground))'
  			},
  			border: 'hsl(var(--border))',
  			input: 'hsl(var(--input))',
  			ring: 'hsl(var(--ring))',
  			chart: {
  				'1': 'hsl(var(--chart-1))',
  				'2': 'hsl(var(--chart-2))',
  				'3': 'hsl(var(--chart-3))',
  				'4': 'hsl(var(--chart-4))',
  				'5': 'hsl(var(--chart-5))'
  			}
  		},
  		fontFamily: {
  			oswald: ['Oswald', 'sans-serif'],
  			montserrat: ['Montserrat', 'sans-serif']
  		},
  		borderRadius: {
  			lg: 'var(--radius)',
  			md: 'calc(var(--radius) - 2px)',
  			sm: 'calc(var(--radius) - 4px)'
  		}
  	}
  },
  plugins: [require("tailwindcss-animate")], // No additional Tailwind plugins used in this project
};