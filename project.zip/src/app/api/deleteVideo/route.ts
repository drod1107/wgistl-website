// src/app/api/deleteVideo/route.ts

import { NextResponse } from 'next/server';
import ServerDriveUtil from '@/lib/driveUtil';

export async function POST(request: Request) {
  try {
    const { videoId } = await request.json();

    if (!videoId) {
      return NextResponse.json(
        { error: 'Video ID is required' },
        { status: 400 }
      );
    }

    await ServerDriveUtil.deleteVideo(videoId);
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting video:', error);
    return NextResponse.json(
      { error: 'Failed to delete video' },
      { status: 500 }
    );
  }
}
