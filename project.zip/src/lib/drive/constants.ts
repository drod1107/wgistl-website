// src/lib/drive/constants.ts

export const DRIVE_API_BASE = "https://www.googleapis.com/drive/v3";
export const UPLOAD_API_BASE = "https://www.googleapis.com/upload/drive/v3";
